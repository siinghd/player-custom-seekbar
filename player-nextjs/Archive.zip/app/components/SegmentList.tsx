import React from 'react';

const SegmentList = () => {
  return <div>SegmentList</div>;
};

export default SegmentList;
